﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buisness_APP.BL
{
    class Credential
    {
        public string name;
        public string password;
        public string role;
    }
}
