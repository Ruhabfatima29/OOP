﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buisness_APP.BL
{
    class ElectedParty
    {
      public string party;
      public string symbol;
      public string founder;
      public int partyCouter;
    }
}
