﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenges.BL
{
    class Product
    {
        public string id;
        public string name;
        public int price;
        public string category;
        public string brandName;
        public string country;
    }
}
