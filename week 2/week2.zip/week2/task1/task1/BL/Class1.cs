﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task1.BL
{
    class Students
    {
        public string name;
        public int roll_no;
        public float cgpa;
        public string department;
        public char isHostellide;
    }
}
